# 🤖 ᴛᴏxɪᴄ ᴀɪ ʙᴀᴋᴀ ɢᴀᴍᴇ & ᴄʜᴀᴛʙᴏᴛ  
<p align="center">⚡ ʏᴇ ᴀᴅᴠᴀɴᴄᴇ ᴀɪ ɢᴀᴍᴇʙᴏᴛ ʜᴀɪ ⚡</p>

<p align="center">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
</p>

<h1 align="center">🚩🚩 𝐉𝐀𝐈 𝐁𝐀𝐉𝐑𝐀𝐍𝐆 𝐁𝐀𝐋𝐈 🚩🚩</h1>
​<p align="center">
<p align="center">
<img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=900&color=F7006A&width=650&lines=🍁🚩+𝗣𝗢𝗪𝗘𝗥𝗘𝗗+𝗕𝗬+𝗧𝗢𝗫𝗜𝗖;🤖+𝗔𝗗𝗩𝗔𝗡𝗖𝗘+𝗔𝗜+𝗖𝗛𝗔𝗧+𝗦𝗬𝗦𝗧𝗘𝗠;⚡+𝗔𝗨𝗧𝗢+𝗥𝗘𝗦𝗣𝗢𝗡𝗗𝗘𝗥+𝗕𝗢𝗧">
</p>
​<h1 align="center">


<a href="https://t.me/lll_TOXICC_PAPA_lll">
<img src="https://files.catbox.moe/gyi5iu.jpg" alt="ToxicBaka Bot" width="400" style="border-radius: 20px; box-shadow: 0px 0px 20px rgba(0,0,0,0.5);">
</a>


🫧 𝐓𝐨𝐱𝐢𝐜𝐁𝐚𝐤𝐚 𝐁𝐨𝐭 ×͜࿐




<i>𝙰 𝙿𝚛𝚘𝚓𝚎𝚌𝚝 𝙱𝚢 <b>𝐈ꜱʜᴀ𝐁ᴏᴛꜱ</b></i>
</h1>
​<p align="center">
<b>Advanced AI-Powered RPG, Economy & Management Bot.</b>
</p>
<p align="center"> ​⚙️ ─「 𝐃𝐄𝐏𝐋𝐎𝐘 」─
​<h3 align="center">🚀 Deploy On Heroku</h3>
​<p align="center">
<a href="https://dashboard.heroku.com/new?template=https://github.com/toxicpapa00/Bakaa">
<img src="https://img.shields.io/badge/⚡%20Deploy%20To%20Heroku-purple?style=for-the-badge&logo=heroku" width="250">
</a>
</p>
​<h3 align="center">🌐 Deploy On Render</h3>
​<p align="center">
<a href="https://render.com/deploy?repo=https://github.com/toxicpapa00/Bakaa">
<img src="https://img.shields.io/badge/🚀%20Deploy%20To%20Render-orange?style=for-the-badge&logo=render" width="250">
</a>
</p>
​🧠 ─「 𝐅𝐄𝐀𝐓𝐔𝐑𝐄𝐒 」─
​🔥 Advanced AI System
​Baka Persona: Sassy, cute Indian girl (Hinglish) powered by Mistral AI.

​Sticker Reply: Reacts to stickers with her own cute sticker collection.

​Narrator: AI narrates /kill and /rob battles dynamically.

​Media: /draw (Anime Art) & /speak (Anime Voice).
​⚔️ RPG & Economy

​Combat: Kill users for loot (Boosted by Weapons).

​Robbery: 100% Success Rate (Blocked only by Armor).

​Shop: Buy 60+ Items (Weapons, Armor, Flex).

​Inventory: Visual inventory with rarity tags and Fair Play limits.

​Revive: Auto-revive in 6h or pay to revive instantly.
​💍 Social System (ShreyaBots Special)

​Marriage: Propose to users. Couples get 5% Tax on transfers.

​Protection: Shared shields between partners.

​Waifu Gacha: Collect anime characters by guessing names in groups.

​⚙️ 𝐄𝐧𝐯𝐢𝐫𝐨𝐧𝐦𝐞𝐧𝐭 𝐕𝐚𝐫𝐢𝐚𝐛𝐥𝐞𝐬
Variable Description Required
```bash
BOT_TOKEN Your Bot Token from @BotFather ✅

MONGO_URI MongoDB Connection String ✅

OWNER_ID Your Telegram User ID ✅

MISTRAL_API_KEY Mistral AI Key (For Chatbot) ✅

GIT_PYTHON_REFRESH Set value to quiet ✅

LOGGER_ID Channel ID for Logs (e.g. -100xxxx) ✅
```

🔧 ─「 𝐈𝐍𝐒𝐓𝐀𝐋𝐋 」─
​If you want to run the bot on your own PC or VPS:
# Clone Repo
```bash
git clone [https://github.com/toxicpapa00/Bakaa](https://github.com/toxicpapa00/Bakaa)
cd ToxicBakaBot
```
# Install Dependencies
```bash
pip install -r requirements.txt
```
# Run Bot
```bash
python3 Ryan.py
```
<h3 align="center">
Made with ❤️ by <a href="https://t.me/lll_TOXICC_PAPA_lll">𝗧𝗢𝗫𝗜𝗖</a>

Owner of <b>IshaBots</b>
</h3>
